<template>
  <div class="video-containe">视频

  </div>
</template>>

<script>
export default {
  name: 'VideoIndex',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {

  },
  mounted () { },
  methods: {}
}
</script>
<style lang="less" scoped>
</style>"