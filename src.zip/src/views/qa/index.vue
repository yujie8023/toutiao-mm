<template>
  <div class="qa-containe">问答

  </div>
</template>>

<script>
export default {
  name: 'QaIndex',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {

  },
  mounted () { },
  methods: {}
}
</script>
<style lang="less" scoped>
</style>"