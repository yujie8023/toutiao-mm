    <template>
  <div class="">
    <van-button v-if="isFollowed"
                class="follow-btn"
                round
                size="small"
                :loading="loading"
                @click="onFollow">已关注</van-button>
    <van-button v-else
                class="follow-btn"
                type="info"
                color="#3296fa"
                round
                size="small"
                icon="plus"
                :loading="loading"
                @click="onFollow">关注</van-button>
  </div>
</template>
    <script>

import { addFollow, deleteFollow } from '@/api/user'

export default {
  name: 'FollowUser',
  components: {},
  props: {
    isFollowed: {
      type: Boolean,
      required: true
    }
  },
  data () {
    return {
      loading: false
    }
  },
  computed: {},
  watch: {},
  created () { },
  mounted () { },
  methods: {
    async onFollow () {
      this.followLoading = true//展示关注按钮的loading状态

      try {
        if (this.article.is_followed) {
          // 已关注,取消关注
          await deleteFollow(this.article.aut_id)
          // console.log(data)
        } else {
          // 没有关注,添加关注
          await addFollow(this.article.aut_id)
          // console.log(data)
        }
        this.article.is_followed = !this.article.is_followed

      } catch (err) {

        let message = '操作失败,请重试'
        if (err.response && err.response.status === 400) {
          message = '不能关注自己'
        }
        this.$toast(message)
      }
      this.followLoading = false//关闭关注按钮的loading状态

    }
  }
}
    </script>
    <style lang="less"scoped>
</style>

